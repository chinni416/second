#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"QIODevice"
#include"QTextStream"
#include"QFile"
#include"QDebug"

QFile file("/home/anil/Desktop/qt/sensors123/text.txt");
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_send_clicked()
{
    QTextStream in(&file);
    QString temp,heart;
    temp=ui->tempa->text();
    heart=ui->heart->text();
    if(file.open(QIODevice::Append))
    {
        qDebug()<<"123";
        in<<"tempareture"<<"\t"<<temp <<endl;
        in<<"hear_beat"<<"\t"<<heart<<endl;
    }

    file.close();
}
